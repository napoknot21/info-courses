﻿using UnityEngine;

public class SolucionesEjerciciosArrays : MonoBehaviour
{
    public GameObject[] balls;

    // Start is called before the first frame update
    void Start()
    {
        balls = GameObject.FindGameObjectsWithTag("ball");
    }

    // Update is called once per frame
    void Update()
    {
        //Ejercicio 1. Pulsando Q, impulsa todas las bolas en direcciones aleatorias:
        if (Input.GetKeyDown(KeyCode.Q))
        {
            for (int i = 0; i < balls.Length; i++)
            {
                float randomForceX = Random.Range(-100, 100);
                float randomForceZ = Random.Range(-100, 100);

                balls[i].GetComponent<Rigidbody>().AddForce(new Vector3(randomForceX, 0, randomForceZ));
            }
        }

        //Ejercicio 2. Pulsando W, desactiva todas las bolas de la escena. 
        if (Input.GetKeyDown(KeyCode.W))
        {
            foreach (GameObject go in balls)
            {
                go.SetActive(false);
            }
        }

        //Ejercicio 3. Pulsando E, Muestra en la consola el numero total de bolas que tiene el array.
        //Pista: recuerda que puedes acceder avarias propiedades del array escribiendo el nombre del array seguido de un punto. "nombreArray."
        if (Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log("Hay un total de: " + balls.Length + "bolas");
        }


        //Ejercicio 4. Pulsando R, Accede a la bola del índice 2 y duplica su tamaño. 
        if (Input.GetKeyDown(KeyCode.R))
        {
            balls[2].transform.localScale *= 2f;
        }

        //Ejercicio 5. Pulsando T, Haz que todas las bolas desaparezcan menos la guardada en el indice 5 del array.
        if (Input.GetKeyDown(KeyCode.T))
        {
            for (int i = 0; i < balls.Length; i++)
            {
                if (i != 5)
                {
                    float randomForceX = Random.Range(-100, 100);
                    float randomForceZ = Random.Range(-100, 100);

                    balls[i].GetComponent<Rigidbody>().AddForce(new Vector3(randomForceX, 0, randomForceZ));
                }
            }
        }

        //Ejercicio 6. Pulsando Y, randomiza la escala de todas las bolas entre los valores de 0.5f, y 2;
        if (Input.GetKeyDown(KeyCode.Y))
        {
            foreach (GameObject go in balls)
            {
                float randomScale = Random.Range(0.5f, 2f);
                go.transform.localScale = new Vector3(randomScale, randomScale, randomScale);
            }

        }

        //Ejercicio 7. Pulsando U, desactiva la gravedad de las bolas y añade un empuje hacia arriba a cada bola.
        if (Input.GetKeyDown(KeyCode.U))
        {
            foreach (GameObject go in balls)
            {
                go.GetComponent<Rigidbody>().useGravity = false;
                go.GetComponent<Rigidbody>().AddForce(Vector3.up * 5f);
            }
        }
    }
}