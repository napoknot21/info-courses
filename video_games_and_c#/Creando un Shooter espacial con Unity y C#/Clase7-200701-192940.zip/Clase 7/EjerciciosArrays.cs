﻿using UnityEngine;

public class EjerciciosArrays : MonoBehaviour
{
    public GameObject[] balls;

    // Start is called before the first frame update
    void Start()
    {
        balls = GameObject.FindGameObjectsWithTag("ball");
    }

    // Update is called once per frame
    void Update()
    {
        //Ejercicio 1. Pulsando Q, impulsa todas las bolas en direcciones aleatorias:
        if (Input.GetKeyDown(KeyCode.Q))
        {
        }

        //Ejercicio 2. Pulsando W, desactiva todas las bolas de la escena. 
        if (Input.GetKeyDown(KeyCode.W))
        {
        }

        //Ejercicio 3. Pulsando E, Muestra en la consola el numero total de bolas que tiene el array.
        //Pista: recuerda que puedes acceder avarias propiedades del array escribiendo el nombre del array seguido de un punto. "nombreArray."
        if (Input.GetKeyDown(KeyCode.E))
        {
        }

        //Ejercicio 4. Pulsando R, Accede a la bola del índice 2 y duplica su tamaño. 
        if (Input.GetKeyDown(KeyCode.R))
        {
        }

        //Ejercicio 5. Pulsando T, Haz que todas las bolas desaparezcan menos la guardada en el indice 5 del array.
        if (Input.GetKeyDown(KeyCode.T))
        {
        }

        //Ejercicio 6. Pulsando Y, randomiza la escala de todas las bolas entre los valores de 0.5f, y 2;
        if (Input.GetKeyDown(KeyCode.Y))
        {
        }

        //Ejercicio 7. Pulsando U, desactiva la gravedad de las bolas y añade un empuje hacia arriba a cada bola.
        if (Input.GetKeyDown(KeyCode.U))
        {
        }
    }
}