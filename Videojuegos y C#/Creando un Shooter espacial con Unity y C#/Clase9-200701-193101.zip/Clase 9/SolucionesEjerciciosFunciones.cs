﻿using UnityEngine;

public class SolucionesEjerciciosFunciones : MonoBehaviour
{
    //Referencia a gameobjects del ejercicio 4.
    public GameObject a;
    public GameObject b;

    // Start is called before the first frame update
    void Start()
    {
        //1. Función que devuelva el mayor de dos números recibidos.
        Debug.Log("El número más grande es: " + Ejercicio1(10, 5));

        //2. Realice una función que calcule si el numero recibido es par o impar. 
        Ejercicio2(25);

        //3. Realice un programa que devuelva la raíz cuadrada del número recibido. 
        //PISTA: Utiliza las funciones de la clase "Mathf."
        Debug.Log("La raiz cuadrada de 25 es: " + Ejercicio3(25));

        //4. Realice una función que calcule la distancia entre dos gameobjects.
        Debug.Log("La distancia entre los dos gameobjects es de: " + Ejercicio4(a, b));
    }

    //Solución Ejercicio 1
    private float Ejercicio1(float num1, float num2)
    {
        if (num1 > num2)
        {
            return num1;
        }
        else
        {
            return num2;
        }
    }

    //Solución Ejercicio 2
    private void Ejercicio2(float num)
    {
        if ((num % 2) == 0)
        {
            Debug.Log("El número " + num + " es par.");
        }
        else
        {
            Debug.Log("El número " + num + " es impar.");
        }
    }

    //Solución Ejercicio 3
    private float Ejercicio3(float num)
    {
        return Mathf.Sqrt(num);
    }

    //Solución Ejercicio 4
    private float Ejercicio4(GameObject a, GameObject b)
    {
        return Vector3.Distance(a.transform.position, b.transform.position);
    }
}
