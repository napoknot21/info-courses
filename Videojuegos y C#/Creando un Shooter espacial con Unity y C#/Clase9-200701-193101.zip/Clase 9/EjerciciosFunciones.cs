﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EjerciciosFunciones : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //1. Función que devuelva el mayor de dos números recibidos.
        //2. Realice una función que calcule si el numero recibido es par o impar. 
        //3. Realice un programa que devuelva la raíz cuadrada del número recibido. 
        //PISTA: Utiliza las funciones de la clase "Mathf."
        //4. Realice una función que calcule la distancia entre dos gameobjects.
    }
}
